SMART WATCH FINDER - ANDROID PROJECT

এই ফোল্ডারটি Android APK তৈরির Capacitor project starter।

প্রয়োজন:
- Node.js ও npm
- Android Studio
- Android SDK
- JDK 21

ধাপ:
1. এই ফোল্ডারটি PC-তে Extract করুন।
2. ফোল্ডারের ভিতরে Terminal/CMD খুলুন।
3. চালান: npm install
4. চালান: npx cap add android
5. চালান: npx cap sync android
6. চালান: npx cap open android
7. Android Studio-তে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।

গুরুত্বপূর্ণ:
- ওয়েব অ্যাপের Excel Import, Serial Search, Copy এবং JSON Import/Export ফিচার www/index.html-এ আছে।
- প্রথম Excel import-এর সময় SheetJS লাইব্রেরি CDN থেকে লোড হয়; তাই প্রথমবার ইন্টারনেট লাগবে।
- JSON backup export/import ব্রাউজারের লোকাল ফাইল হিসেবে কাজ করে।


ONLINE APK BUILD (GitHub Actions):
1. GitHub-এ login করে New repository তৈরি করুন, নাম দিন Smart-Watch-Finder।
2. ZIP Extract করে সব ফাইল ও hidden .github folder-সহ repository-তে upload করুন।
3. Commit changes করে main branch-এ রাখুন।
4. Repository-এর Actions tab খুলুন।
5. 'Build Smart Watch Finder APK' workflow নির্বাচন করে Run workflow চাপুন।
6. Build শেষ হলে workflow run-এর নিচে Artifacts থেকে Smart-Watch-Finder-APK.zip download করুন।
7. ZIP extract করলে app-debug.apk পাবেন।

নোট: প্রথম build-এ GitHub Actions Android project তৈরি করে APK build করবে। এটি debug APK; Play Store প্রকাশের signed release APK নয়।
